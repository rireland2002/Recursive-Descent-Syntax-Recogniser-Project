public class Generate extends AbstractGenerate
{
    public void reportError(Token token, String string) throws CompilationException//Pass the current token so line and text can be extracted and then use string to print custom error message
    {
        System.out.println(string);//Output custom message, tried to do this through compilation exception but sometimes it does not print the error message
        throw new CompilationException(string);//throw compilation exception and move onto next file
    }
}