import java.io.IOException;
//Author:Raff Ireland
public class SyntaxAnalyser extends AbstractSyntaxAnalyser
{
    public SyntaxAnalyser(String filename)
    {
        try
        {
            lex = new LexicalAnalyser(filename);//Initialise the lex object using filename passed from the compile class
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

    public void _statementPart_()throws CompilationException, IOException
    {
        if(nextToken.symbol == 2)//Check if the first token is the distinguished symbol begin
        {
            myGenerate.commenceNonterminal("StatementPart");//Commence statement part in which all other methods are contained
            acceptTerminal(nextToken.symbol);//Accept the begin symbol and get next token
            statementList();//Call the statement list function as we have a valid begin system
            acceptTerminal(nextToken.symbol);//After the final statement has been succesfully completed we exit statement list and accept the end token
            myGenerate.finishNonterminal("StatementPart");//Finish the statement part function and move onto next program if there is one
        }
        else
        {
            myGenerate.reportError(nextToken, "Distinguished symbol does not match in statement part on line " + nextToken.lineNumber+" Token:"+nextToken.text+" Begin Token expected");//If the begin symbol is incorrect such as the begim symbol we print this symbol, the line its on and the function it is within, this is the same for all errors after this point so I will not explain unless there is a difference   
        }    
    }

    public void acceptTerminal(int tokenID)throws IOException, CompilationException
    {
        myGenerate.insertTerminal(nextToken);//I verify before passing a token to this method so I can akways insert terminal when it is called without worry
        nextToken = lex.getNextToken();//We move onto the next token in the input for use inside functions below
    }

   
    public void statementList()throws IOException, CompilationException
    {
        myGenerate.commenceNonterminal("StatementList");//Every time we start a new statement list we output using the commence non terminal method, this occurs for as many statements as we have in the input file
        if(nextToken.symbol != Token.endSymbol || nextToken.symbol != Token.untilSymbol)//Check whether the current token is the end or until token, if not we continue as normal, if it is then we skip the below statements and finish statement list
        {
            statement();//Call the statement function
            if(nextToken.symbol == 30)//Check for a semicolon which would indicate there is another statement following the one we have just parsed
            {
                acceptTerminal(nextToken.symbol);//Accept the semicolon and get next token
                statementList();//Call statement list recursively
            }
            myGenerate.finishNonterminal("StatementList");//All statement lists should finish consecutively unless within a loop, in that case they terminate when the loop does
        }        
    }

    public void statement()throws CompilationException, IOException
    {
        myGenerate.commenceNonterminal("Statement");//Same as above but for statement
        switch (nextToken.symbol)//We have a switch case so we can see which statement function to call depending on the type of the current token, seeing as each function starts with a distinct token from one another
        {
            case 3://If the call symbol is detected call the procedure statement function, since this is the same for all below I will just note the different tokens, the switch case ensures we always enter a statement with at least the first token being correct
                procedureStatement();
                break;

            case 17://if token
                ifStatement();
                break;

            case 16://identifier token
                assignmentStatement();
                break;

            case 36://while token
                whileStatement();
                break;
            
            case 7://do token
                untilStatement();
                break;

            case 37://for token
                forStatement();
                break;

            default:
                myGenerate.reportError(nextToken, "Terminal not valid for any statement on line "+ nextToken.lineNumber+" Token:"+nextToken.text+" Token should match one of the following: Assignment: 312TOKEN IDENTIFIER | If: 312TOKEN if| While: 312TOKEN while | Procedure:312TOKEN call | Until:312TOKEN do | For:312TOKEN for");//This is how errors for function with multiple options occur, I list the token that is wrong, the line it is on and the possible options it can be, this is the same for any function below with multiple options. I chose to do this instead of using a basic switch case inside something like accept terminal as it allow for detailed error messages and possible solutions, this error occurs if the first token after begin matches none of the statements
                break;
        }
        myGenerate.finishNonterminal("Statement");//Finish statement
    }

    public void assignmentStatement() throws CompilationException, IOException
    {
        
            myGenerate.commenceNonterminal("AssignmentStatement");//Same as above
            acceptTerminal(nextToken.symbol);//Same as usual
            if(nextToken.symbol == 1)//Check for becomes symbol
            {
                acceptTerminal(nextToken.symbol);//I will stop noting this here as it is never altered in its operation
                if(nextToken.symbol == 16 || nextToken.symbol == 20 || nextToken.symbol == 26)//Check if the current token is an identifier, number constant or left parenthesis as these are the base types of this branch, with the branch being expression -> term -> factor -> identifier | number constant | (expression)
                {   
                    expression();//Call expression if token above matches
                    myGenerate.finishNonterminal("AssignmentStatement");//exit assigment statement
                }
                else if(nextToken.symbol == 31)//Check for a string constant as this is the other option for assignment statement
                {
                    acceptTerminal(nextToken.symbol);
                    myGenerate.finishNonterminal("AssignmentStatement");//same as above
                }
                else
                {
                    myGenerate.reportError(nextToken, "Terminal does not in assignment statement match inside assigment statement on line "+nextToken.lineNumber+" Token:"+nextToken.text+" Token should match one of the following: 312TOKEN IDENTIFIER | 312TOKEN STRING | 312TOKEN NUMBER | 312TOKEN (");//multiple option error
                }
            }
            else
            {
                myGenerate.reportError(nextToken, "Terminal does not match in assignment statement on line "+nextToken.lineNumber+" Token:"+nextToken.text+" 312TOKEN := Token expected");//single option error
            }
      
        
    }

    public void ifStatement()throws CompilationException, IOException
    {
        myGenerate.commenceNonterminal("IfStatement");
        acceptTerminal(nextToken.symbol);
        if(nextToken.symbol == 16)//check for identifier as this is what comes after the if symbol in the grammar
        {
            condition();//call condition if the above check is passed
            if(nextToken.symbol == 34)//Check we leave the condition with the then symbol
            {
                acceptTerminal(nextToken.symbol);
                statementList();//call statement list as per grammar rules
                if(nextToken.symbol == 8)//check for end symbol to indicate we follow the first option of if statement
                {
                    acceptTerminal(nextToken.symbol);
                    if(nextToken.symbol == 17)//check for if statement as this is the end of the if statement
                    {
                        acceptTerminal(nextToken.symbol);
                        myGenerate.finishNonterminal("IfStatement");//finish if statement
                    }
                    else
                    {
                        myGenerate.reportError(nextToken, "Terminal does not match in if statement on line "+nextToken.lineNumber+" Token:"+nextToken.text+" 312TOKEN if Token expected");//single option error
                    }
                }
                else if(nextToken.symbol == 9)//check for the else symbol indicating we follow the second case of the if statement
                {
                    acceptTerminal(nextToken.symbol);
                    statementList();
                    if(nextToken.symbol == 8)//Same as above from checking for the end symbol, then if symbol, then finishing if statement with same error checks
                    {
                        acceptTerminal(nextToken.symbol);
                        if(nextToken.symbol == 17)
                        {
                            acceptTerminal(nextToken.symbol);
                            myGenerate.finishNonterminal("IfStatement");
                        }
                        else
                        {
                            myGenerate.reportError(nextToken, "Terminal does not match in if statement on line "+nextToken.lineNumber+" Token:"+nextToken.text+" 312TOKEN if Token expected");
                        }
                    }
                    else
                    {
                        myGenerate.reportError(nextToken, "Terminal does not match in if statement on line "+nextToken.lineNumber+" Token:"+nextToken.text+" 312TOKEN end Token expected");
                    }
                }
                else
                {
                    myGenerate.reportError(nextToken, "Terminal does not match in if statement on line "+nextToken.lineNumber+" Token:"+nextToken.text+" Token should match one of the following: 312TOKEN end | 312TOKEN else");//multi option error
                }
            }
            else
            {
                myGenerate.reportError(nextToken, "Terminal does not match in if statement on line "+nextToken.lineNumber+" Token:"+nextToken.text+" 312TOKEN then Token expected");//single option error
            }
        }
        else
        {
            myGenerate.reportError(nextToken, "Terminal does not match in if statement on line "+nextToken.lineNumber+" Token:"+nextToken.text+" 312TOKEN IDENTIFIER Token expected");//single option error
        }
    }

    public void whileStatement() throws CompilationException, IOException
    {
        myGenerate.commenceNonterminal("WhileStatement");
        acceptTerminal(nextToken.symbol);
        if(nextToken.symbol == 16)//check for identifier
        {
            condition();//call condition on succesful check
            if(nextToken.symbol == 23)//check for loop token
            {
                acceptTerminal(nextToken.symbol);
                statementList();
                if(nextToken.symbol == 8)//check for end symbol
                {
                    acceptTerminal(nextToken.symbol);
                    if(nextToken.symbol == 23)//check for loop symbol according to grammar rules
                    {
                        acceptTerminal(nextToken.symbol);
                        myGenerate.finishNonterminal("WhileStatement");
                    }
                    else
                    {
                        myGenerate.reportError(nextToken, "Terminal does not match in while statement on line "+nextToken.lineNumber+" Token:"+nextToken.text+" 312TOKEN loop Token expected");
                    }
                }
                else
                {
                    myGenerate.reportError(nextToken, "Terminal does not match in while statement on line "+nextToken.lineNumber+" Token:"+nextToken.text+" 312TOKEN end Token expected");
                }
            }
            else
            {
                myGenerate.reportError(nextToken, "Terminal does not match in while statement on line "+nextToken.lineNumber+" Token:"+nextToken.text+" 312TOKEN loop Token expected");
            }  
        }
        else
        {
            myGenerate.reportError(nextToken, "Terminal does not match in while statement on line "+nextToken.lineNumber+" Token:"+nextToken.text+" 312TOKEN IDENTIFIER Token expected");
        }
    }

    public void procedureStatement() throws CompilationException, IOException
    {
        
            myGenerate.commenceNonterminal("ProcedureStatement");
            acceptTerminal(nextToken.symbol);
            if(nextToken.symbol == 16)//Check for identifier as per grammar rules
            {
                acceptTerminal(nextToken.symbol);
                if(nextToken.symbol == 20)//Check fot left parenthesis
                {
                    acceptTerminal(nextToken.symbol);
                    if(nextToken.symbol == 16)//Check for identifier
                    {
                        argumentList();//Call argument list on succesful check
                        if(nextToken.symbol == 29)//Check for right parenthesis on exiting argument list
                        {
                            acceptTerminal(nextToken.symbol);
                            myGenerate.finishNonterminal("ProcedureStatement");       
                        }
                        else
                        {
                            myGenerate.reportError(nextToken, "Terminal does not match in procedure statement on line "+nextToken.lineNumber+" Token:"+nextToken.text+" 312TOKEN ) Token expected");//Errors as per usual rules
                        }
                    }
                    else
                    {
                        myGenerate.reportError(nextToken, "Terminal does not match in procedure statement on line "+nextToken.lineNumber+" Token:"+nextToken.text+" 312TOKEN IDENTIFIER Token expected");
                    }
                }
                else
                {
                    myGenerate.reportError(nextToken, "Terminal does not match in procedure statement on line "+nextToken.lineNumber+" Token:"+nextToken.text+" 312TOKEN ( Token expected"); 
                }
            }
            else
            {
                myGenerate.reportError(nextToken, "Terminal does not match in procedure statement on line "+nextToken.lineNumber+" Token:"+nextToken.text+" 312TOKEN IDENTIFIER Token expected");
            }
        }
       
    

    public void untilStatement() throws CompilationException, IOException
    {
        myGenerate.commenceNonterminal("UntilStatement");
        acceptTerminal(nextToken.symbol);
        statementList();
        if(nextToken.symbol == 35)//check for until symbol
        {
            acceptTerminal(nextToken.symbol);
            if(nextToken.symbol == 16)//Check for identifier
            {
                condition();//call condition
                myGenerate.finishNonterminal("UntilStatement");
            }
            else
            {
                myGenerate.reportError(nextToken, "Terminal does not match in until statement on line "+nextToken.lineNumber+" Token:"+nextToken.text+" 312TOKEN IDENTIFIER Token expected");
            }
        }
        else
        {
            myGenerate.reportError(nextToken, "Terminal does not match in until statement on line "+nextToken.lineNumber+" Token:"+nextToken.text+" 312TOKEN until Token expected");
        }
    }

    public void forStatement()throws CompilationException, IOException
    {
        myGenerate.commenceNonterminal("ForStatement");
        acceptTerminal(nextToken.symbol);
        if(nextToken.symbol == 20)//From this point since I have explained what the checks are for I will just list the token being checked and any points of interest, from reading the checks you will see they follow the grammar rules as defined in the spec- left parenthesis
        {
            acceptTerminal(nextToken.symbol);
            if(nextToken.symbol == 16)//identifier
            {
                assignmentStatement();
                if(nextToken.symbol == 30)//semicolon
                {
                    acceptTerminal(nextToken.symbol);
                    if(nextToken.symbol == 16)//identifier
                    {
                        condition();
                        if(nextToken.symbol == 30)//semicolon
                        {
                            acceptTerminal(nextToken.symbol);
                            if(nextToken.symbol == 16)//identifier
                            {
                                assignmentStatement();
                                if(nextToken.symbol == 29)//right parenthesis
                                {
                                    acceptTerminal(nextToken.symbol);
                                    if(nextToken.symbol == 7)//do 
                                    {
                                        acceptTerminal(nextToken.symbol);
                                        statementList();
                                        if(nextToken.symbol == 8)//end
                                        {
                                            acceptTerminal(nextToken.symbol);
                                            if(nextToken.symbol == 23)//loop
                                            {
                                                acceptTerminal(nextToken.symbol);
                                                myGenerate.finishNonterminal("ForStatement");
                                            }
                                            else
                                            {
                                                myGenerate.reportError(nextToken, "Terminal does not match in for statement on line "+nextToken.lineNumber+" Token:"+nextToken.text+" 312TOKEN loop Token expected");
                                            }
                                        }
                                        else
                                        {
                                            myGenerate.reportError(nextToken, "Terminal does not match in for statement on line "+nextToken.lineNumber+" Token:"+nextToken.text+" 312TOKEN end Token expected");
                                        }
                                    }
                                    else
                                    {
                                        myGenerate.reportError(nextToken, "Terminal does not match in for statement on line "+nextToken.lineNumber+" Token:"+nextToken.text+" 312TOKEN do Token expected");
                                    }
                                }
                                else
                                {
                                    myGenerate.reportError(nextToken, "Terminal does not match in for statement on line "+nextToken.lineNumber+" Token:"+nextToken.text+" 312TOKEN ) Token expected");
                                }
                            }
                            else
                            {
                                myGenerate.reportError(nextToken, "Terminal does not match in for statement on line "+nextToken.lineNumber+" Token:"+nextToken.text+" 312TOKEN IDENTIFIER Token expected");
                            }
                        }
                        else
                        {
                            myGenerate.reportError(nextToken, "Terminal does not match in for statement on line "+nextToken.lineNumber+" Token:"+nextToken.text+" 312TOKEN ; Token expected");
                        }
                    }
                    else
                    {
                        myGenerate.reportError(nextToken, "Terminal does not match in for statement on line "+nextToken.lineNumber+" Token:"+nextToken.text+" 312TOKEN IDENTIFIER Token expected");
                    }    
                }
                else
                {
                    myGenerate.reportError(nextToken, "Terminal does not match in for statement on line "+nextToken.lineNumber+" Token:"+nextToken.text+" 312TOKEN ; Token expected");
                }
            }
            else
            {
                myGenerate.reportError(nextToken, "Terminal does not match in for statement on line "+nextToken.lineNumber+" Token:"+nextToken.text+" 312TOKEN IDENTIFIER Token expected");
            }
        }
        else
        {
            myGenerate.reportError(nextToken, "Terminal does not match in for statement on line "+nextToken.lineNumber+" Token:"+nextToken.text+" 312TOKEN ( Token expected");
        }
    }

    public void expression() throws CompilationException, IOException
    {
       
            myGenerate.commenceNonterminal("Expression");
            term();//call term as every expression has at least one term
            if(nextToken.symbol == 24 || nextToken.symbol == 27)//check for a plus or minus symbol
            {
                acceptTerminal(nextToken.symbol);
                expression();//call expression again as per grammar rules
            }
            myGenerate.finishNonterminal("Expression");        
    }
     
    

    public void condition() throws CompilationException, IOException
    {
        myGenerate.commenceNonterminal("Condition");
        acceptTerminal(nextToken.symbol);
        if(nextToken.symbol == 15 || nextToken.symbol == 14 || nextToken.symbol == 11 || nextToken.symbol == 25 || nextToken.symbol == 22 || nextToken.symbol == 21)//check for any of the comparitive operators < > => =< = /=
        {
            conditionalOperator();//call conditional operator as this occurs in every case of a condition
            if(nextToken.symbol == 16 || nextToken.symbol == 31 || nextToken.symbol == 26)//check for identifier, string constant or number constant
            {
                acceptTerminal(nextToken.symbol);
                myGenerate.finishNonterminal("Condition");
            }
            else
            {
                myGenerate.reportError(nextToken, "Terminal does not match in condition on line "+nextToken.lineNumber+" Token:"+nextToken.text+" Token should match one of the following: 312TOKEN IDENTIFIER | 312TOKEN STRING | 312TOKEN NUMBER");     
            }
        }
        else
        {
            myGenerate.reportError(nextToken, "Terminal does not match in condition on line "+nextToken.lineNumber+" Token:"+nextToken.text+" Token should match one of the following: 312TOKEN > | 312TOKEN >= | 312TOKEN /= | 312TOKEN = | 312TOKEN < | 312TOKEN <= ");
        }
    }

    public void conditionalOperator()throws IOException, CompilationException
    {
        myGenerate.commenceNonterminal("ConditionalOperator");//No error needed for this function as we perform necessary checks before even entering and a conditional operator just outputs one of the operators we checked for 
        acceptTerminal(nextToken.symbol);
        myGenerate.finishNonterminal("ConditionalOperator");
    }

    public void term()throws CompilationException, IOException
    {
        myGenerate.commenceNonterminal("Term");
        factor();//every term has at least one factor
        if(nextToken.symbol == 33 || nextToken.symbol == 6)//check for a times or division token
        {
            acceptTerminal(nextToken.symbol);
            term();//recursively call term until all factors have been handled
        }   
        myGenerate.finishNonterminal("Term");
    }

    public void factor() throws CompilationException, IOException
    {
        myGenerate.commenceNonterminal("Factor");
        if(nextToken.symbol == 20)//left parenthesis, check for the expression case 
        {
            acceptTerminal(nextToken.symbol);
            expression();//call factor within factor and loop around
            if(nextToken.symbol == 29)//right parenthesis
            {
                acceptTerminal(nextToken.symbol);
                myGenerate.finishNonterminal("Factor");
            }
        }
        else
        {
            acceptTerminal(nextToken.symbol);
            myGenerate.finishNonterminal("Factor");
        }
    }

    public void argumentList()throws CompilationException, IOException
    {
        
            myGenerate.commenceNonterminal("ArgumentList");
            acceptTerminal(nextToken.symbol);
            if(nextToken.symbol == 5)//comma, indicating there is a following element
            {
                acceptTerminal(nextToken.symbol);//accept the comma token
                argumentList();//recursively call argument list until all identifiers are handled
            }
            myGenerate.finishNonterminal("ArgumentList");
        }
       
    
}